#!/usr/bin/env python
# coding: utf-8

'''
This is the doc string contained in the nicer functions py file
'''

def hallo(name):
    '''
    docstring of nice_func_add3 in nicer functions
    '''
    return 'Hallo' + str(name)