#!/usr/bin/env python
# coding: utf-8

'''
This is the doc string contained in the __init__.py file
'''

def nice_func_add3(a,b,c):
    '''
    docstring of nice_func_add3
    '''
    return a+b+c